#ifndef __LimKey_H
#define __LimKey_H	 
#include "sys.h"

void LimKey_Init(void);



#endif
