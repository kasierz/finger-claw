#ifndef __Timer_H
#define __Timer_H
#include "sys.h"



void TIM2_Int_Init(u16 arr,u16 psc);
void TIM3_Int_Init(u16 arr,u16 psc);
extern u16 COUNT;
extern u16 cnt1_max,cnt2_max;
extern u8 flag1,flag2,flag3,flag4,flag5,flag6,flag7;
extern u8 key,Iskey;

#endif
