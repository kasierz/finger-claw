#ifndef __StepDriver_H
#define __StepDriver_H	 
#include "sys.h"

void StepDriver_Init(void);
void StepDriver_Config(u8 NumOfDriver,u8 Mode);



#endif
